<!DOCTYPE html>
<html>
<head>
    <title>Attendance</title>
    <link rel="stylesheet" type="text/css" href="./css/style.css">
    <style>
        /* Your CSS styles here */
        body {
            font-family: Arial, Helvetica, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f2f2f2;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #ffffff;
            border: 1px solid red;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 85%);
        }

        h2 {
            color: blue;
            text-align: left;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 10px;
            text-align: center;
            border: 1px solid ;
        }

        th {
            background-color: #c1bbdd;
        }

        input[type="text"] {
            width: 80%;
            padding: 6px;
            
        }

        .input[type="submit"] {
            background-color: blue;
            color: white;
            font-size: 16px;
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

         input[type="submit"]:hover {
        background-color: #0066cc; /* Change the background color on hover */
    }

        select {
            width: 100%;
            padding: 5px;
        }

        .success-message {
            color: green;
            font-size: 18px;
            text-align: center;
            font-weight: bold;
        }

        .error-message {
            color: #FF0000;
            font-size: 18px;
            text-align: center;
            font-weight: bold;
        }
        .previous-button {
            background-color: blue;
            color: white;
            font-size: 16px;
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            float: right; /* Align to the right */
        }

        .previous-button:hover {
            background-color: #0066cc;
        }
        /* Style the footer */
.footer {
  text-align: center;
 
  color:black;
  padding: 0px;
  position: relative;
  bottom: 10px;
  width: 100%;
}
    </style>
</head>


<body>
<ul>
  <li><a href="index.html">Home</a></li>
  <li><a href="assesmententer.php">Enter Marks</a></li>
  <li><a href="viewmarks.php">View marks</a></li>
  <li><a href="addstudent.php">Add Students</a></li>
  <li style="float:right"><a class="active" href="index.html">Logout</a></li>
</ul>
    <div class="container">
         <?php
        // Connect to the MySQL database
             $servername = "localhost";
$username = "root";
$password = "";
$dbname = "marks";

        $tablename = $_POST['subject'];

        $conn = mysqli_connect($servername, $username, $password, $dbname);

        // Check connection
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }

        function displayAttendance($tablename, $conn)
        {
            $sql = "SELECT examid,name FROM $tablename";
            $result = mysqli_query($conn, $sql);

            if (mysqli_num_rows($result) > 0) {
                echo "<form method='POST' action=''>";
                echo '<h2 style="color: blue;">Subject: ' . $tablename . '</h2>';
                echo '<table>';
                echo "<tr><th>Exam No</th><th>Name</th><th>obtained Mark</th></tr>";
            
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
                    echo "<td>" . $row['examid'] . "</td>";
                    echo "<td>" . $row['name'] . "</td>";
                    echo "<td>";
                    echo "<input type='text' name='mark[" . $row['examid'] . "]' required>";
                    echo "</td>";
                    echo "</tr>";
                }
            
                echo "<input type='hidden' name='subject' value='$tablename'>";
                echo "</table>";
            
                echo '<br><input type="submit" value="Submit Assessment Marks" style="background-color: blue; color: white; font-size: 16px; padding: 10px; border: none; border-radius: 5px;">';
                echo '<input type="button" class="previous-button" value="Previous" onclick="history.back();">';
                echo "</form>";
            
               // Check if the form was submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['mark'])) {
    // Process and update assessment marks here
    $subject = $_POST['subject'];

    foreach ($_POST['mark'] as $examid => $mark) {
        // Update the mark column for each student based on the input field
        $updateQuery = "UPDATE $tablename SET mark = '$mark' WHERE examid = '$examid'";
        if (mysqli_query($conn, $updateQuery)) {
            // Assessment mark updated successfully
        } else {
            echo '<p style="color: #FF0000; font-size: 18px; text-align: center; font-weight: bold;">Error updating assessment marks: ' . mysqli_error($conn) . '</p>';
        }
    }

    echo '<p style="color: green; font-size: 18px; text-align: center; font-weight: bold;">Assessment marks successfully updated!</p>';
}

            }
             else {
                echo '<p style="color: #FF0000; font-size: 18px; text-align: center; font-weight: bold;">No students found for the given subject code.</p>';
            }
        }

        displayAttendance($tablename, $conn);

        // Close the database connection
        mysqli_close($conn);
        ?>
    </div>
    <footer class="footer">  
<p>@Copyright © 2023 .Designed by Sivaperumal Web Developer</p>  
</footer> 
</body>
</html>
