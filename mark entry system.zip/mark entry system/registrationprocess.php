<?php
// Database connection configuration
$servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "marks";

// Create a database connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check if the connection is successful
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["subject"])) {
        $selectedSubject = $_POST["subject"];

        // Create a table name based on the selected subject

        $numStudents = $_POST["num_students"];
        $successMessages = [];
        $errorMessages = [];

        for ($i = 1; $i <= $numStudents; $i++) {
            $regno = mysqli_real_escape_string($conn, $_POST["examid_$i"]);
            $name = mysqli_real_escape_string($conn, $_POST["name_$i"]);

            // Validate data (you can add more validation as needed)
            if (!empty($regno) && !empty($name)) {
                // Check if the student already exists in the selected subject table
                $checkSql = "SELECT * FROM $selectedSubject WHERE examid = '$regno' AND name = '$name'";
                $result = mysqli_query($conn, $checkSql);

                if (mysqli_num_rows($result) > 0) {
                    // Student with the same registration number and name is already registered in this subject
                    $errorMessages[] = "Student with registration number $regno and name $name is already registered in $selectedSubject.";
                } else {
                    // Insert data into the database table based on the selected subject
                    $sql = "INSERT INTO $selectedSubject (examid, name) VALUES ('$regno', '$name')";
                    if (mysqli_query($conn, $sql)) {
                        $successMessages[] = "Student $i registered successfully.";
                    } else {
                        $errorMessages[] = "Error registering Student $i: " . mysqli_error($conn);
                    }
                }
            } else {
                $errorMessages[] = "Please fill in all fields for Student $i.";
            }
        }

        // Close the database connection
        mysqli_close($conn);
    } else {
        $errorMessages[] = "Please select a subject.";
    }
} else {
    // Handle invalid requests or redirect to an error page
    echo "Invalid request.";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Registration Results</title>
    <style>
        .center-button {
    display: flex;
    justify-content: center;
    margin-top: 20px;
}

.center-button a {
    display: inline-block;
    padding: 10px 20px;
    background-color: #007bff;
    color: #fff;
    text-decoration: none;
    border-radius: 4px;
    font-weight: bold;
    transition: background-color 0.3s ease;
}

.center-button a:hover {
    background-color: #0056b3;
}
    </style>
</head>
<body>
   <center> <h2>Registration Results</h2></center>
    <?php
    // Display success messages
    foreach ($successMessages as $successMessage) {
        echo "<center><p style='color: green;'>$successMessage</p></center>";
    }

    // Display error messages
    foreach ($errorMessages as $errorMessage) {
        echo "<center><p style='color: red; '>$errorMessage</p></center";
    }
    ?>
  <div class="center-button">
    <center><a href="studentdetilsupdate.php">Back to Registration and Update</a></center>
</div>
</body>
</html>
