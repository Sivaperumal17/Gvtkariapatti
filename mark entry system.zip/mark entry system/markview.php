<!DOCTYPE html>
<html>
<head>
    <title>Student Marks</title>
    <link rel="stylesheet" type="text/css" href="./css/style.css">
    <style>
table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 15px;
            text-align: center;
            border: 2px solid ;
        }

        th {
            background-color: #c1bbdd;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #ffffff;
            border: 1px solid red;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 85%);
        }
        /* Style the footer */
.footer {
  text-align: center;
  align-items: center;
  color: black;
  padding: 0px;
  position:relative;
  bottom: 85;
  width: 100%;
}

    </style>
</head>
<body>
<ul>
  <li><a href="index.html">Home</a></li>
  <li><a href="assesmententer.php">Enter Marks</a></li>
  <li><a href="viewmarks.php">View marks</a></li>
  <li><a href="addstudent.php">Add Students</a></li>
  <li style="float:right"><a class="active" href="index.html">Logout</a></li>
</ul>
<div class="container">
<?php
// Establish a database connection (update with your database details)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "marks";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to retrieve student marks for a given subject and calculate ranks
function getStudentMarks($subject) {
    global $conn;

    $marks = array();

    // Ensure the subject table exists before querying
    $subjectTable = strtolower($subject);
    $sql = "SHOW TABLES LIKE '$subjectTable'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Subject table exists, proceed to fetch data
        $marks = array();
        $sql = "SELECT examid, name, mark FROM $subjectTable";
        $result2 = $conn->query($sql);
    
        if ($result2->num_rows > 0) {
            $students = array();
            while ($row = $result2->fetch_assoc()) {
                $examid = $row["examid"];
                $name = $row["name"];
                $mark = $row["mark"];
                $status = $mark < 35 ? "Fail" : "Pass";
    
                $students[] = array(
                    "Exam ID" => $examid,
                    "Name" => $name,
                    "Mark" => $mark,
                    "Status" => $status
                );
            }
    
            $rankedStudents = $students;
            usort($rankedStudents, function($a, $b) {
                return $b['Mark'] - $a['Mark'];
            });
    
            $rank = 1;
            foreach ($students as $student) {
                $examid = $student["Exam ID"];
                $name = $student["Name"];
                $mark = $student["Mark"];
                $status = $student["Status"];
    
                $rankedStudent = current(array_filter($rankedStudents, function($s) use ($examid) {
                    return $s['Exam ID'] == $examid;
                }));
    
                $rankedMark = $rankedStudent ? $rankedStudent['Mark'] : null;
    
                $marks[] = array(
                    "Exam ID" => $examid,
                    "Name" => $name,
                    "Mark" => $mark,
                    "Rank" => $rankedMark ? array_search($rankedMark, array_column($rankedStudents, 'Mark')) + 1 : null,
                    "Status" => $status
                );
    
                $rank++;
            }
        }
    }
    
    
    return $marks;
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["subject"])) {
    $selectedSubject = $_POST["subject"];
    $studentMarks = getStudentMarks($selectedSubject);

    if (count($studentMarks) > 0) {
        $totalStudents = count($studentMarks);
        $passedStudents = 0;
        $failedStudents = 0;

        // Calculate pass percentage
        $passPercentage = ($passedStudents / $totalStudents) * 100;
      

        echo "<table border='1'>";
        echo "<tr><th>Exam ID</th><th>Name</th><th>Marks</th><th>Ranks</th><th>Status</th></tr>";
        foreach ($studentMarks as $student) {
            $examid = $student["Exam ID"];
            $name = $student["Name"];
            $mark = $student["Mark"];
            $rank = $student["Rank"];
            $status = $student["Status"];
          
            $statusStyle = ($status === "Fail") ? "background-color:red;" : "";

            echo "<tr style='$statusStyle'>";
            echo "<td>$examid</td>";
            echo "<td>$name</td>";
            echo "<td>$mark</td>";
            echo "<td>$rank</td>";
            echo "<td>$status</td>";
            echo "</tr>";

            if ($status === "Pass") {
                $passedStudents++;
            } else {
                $failedStudents++;
            }
        }
        echo "</table>";

        // Calculate pass percentage
        $passPercentage = ($passedStudents / $totalStudents) * 100;
        
        echo "<br>";
        echo "<table>";
        echo "<tr>";
        echo "<td>Total Number of  Students:</td>";
        echo "<td>$totalStudents</td>";
        echo "</tr>";
        echo "<tr>";
        echo "<td>Number of Students Passed:</td>";
        echo "<td>$passedStudents</td>";
        echo "</tr>";
        echo "<tr>";
        echo "<td>Number of Students Failed:</td>";
        echo "<td>$failedStudents</td>";
        echo "</tr>";
        $pass=number_format($passPercentage, 3);
        echo "<td>Over all Pass Percentage:</td>";
        echo "<td>" . number_format($passPercentage, 3) . "%</td>";
        echo "</tr>";

        if ($passPercentage >= 50) {
            echo "<tr class='pass'>";
            echo "</tr>";
            echo "<tr class='pass_message'>";
            echo "<td colspan='2' style='color: green;'>Congratulations! The majority of students passed and pass percentage $pass % is good. 😊</td>";
            echo "</tr>";
        } else {
            echo "<tr class='fail'>";
            echo "</tr>";
            echo "<tr class='fail_message'>";
            echo "<td colspan='2' style='color:red;'>Unfortunately, the pass percentage is below 50%. 😔</td>";
            echo "</tr>";
        }
        echo "</table>";

    } else {
        echo "No data found for the selected subject.";
    }
}


// Close the database connection
$conn->close();
?>
 <footer class="footer">  
<p>@Copyright © 2023 .Designed by Sivaperumal Web Developer</p>  
</footer> 
</div>
</body>
</html>
