
<!DOCTYPE html>
<html>
<head>
    <title>Assesment Mark</title>

    <link rel="stylesheet" type="text/css" href="./css/style.css">
    <style>
        /* Reset some default browser styles */
body, h1, form {
  margin: 0;
  padding: 0;
}

/* Apply styles to the container */
.container {
  max-width: 400px;
  margin: 100px auto;
  padding: 20px;
  
  border-radius: 10px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 85%);
  text-align: center;
}

/* Style the heading */
h1 {
  font-size: 24px;
  margin-bottom: 20px;
}

/* Style the form elements */
label {
            display: block;
            margin-bottom: 10px;
            color: #424949;
        }


select, input[type="text"] {
  width: 100%;
  padding: 10px;
  margin-bottom: 10px;
  border: 2px solid ;
  border-radius: 10px;
}

input[type="submit"] {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 40px;
            border-radius: 10px;
            cursor: pointer;
            font-size: 16px;
        }

/* Style the footer */
.footer {
  text-align: center;
  background-color: #333;
  color: #fff;
  padding: 0px;
  position: absolute;
  bottom: 0;
  width: 100%;
}
    </style>

 
</head>
<body>
<ul>
  <li><a href="index.html">Home</a></li>
  <li><a href="assesmententer.php">Enter Marks</a></li>
  <li><a href="viewmarks.php">View marks</a></li>
  <li><a href="addstudent.php">Add Students</a></li>
  <li style="float:right"><a class="active" href="index.html">Logout</a></li>
</ul>

    <div class="container">
        <h1>Students Assesment Enter Panel</h1>
        <form method="POST" action="enter_marks.php">
       
            <label for="semester">Select Sections (பிரிவுகளைத் தேர்ந்தெடுக்கவும்):</label>
            <select name="semester" id="semester">
            <option value="">Section (பிரிவு)</option>
           
            <option value="1">11 th A1</option>
            <option value="2">11 th A2</option>
            <option value="3">11 th B1</option>
            <option value="4">11 th B2</option>
            <option value="5">12 th A1</option>
            <option value="6">12 th A2</option>
            <option value="7">12 th B1</option>
            <option value="8">12 th B2</option>
           
            <!-- Add more semesters here -->
      
           </select><br>
           <label for="subject">Select Subjects (பாடங்களைத் தேர்ந்தெடுக்கவும்)</label>
             <select name="subject" id="subject">
             </select><br><br>

            <input type="submit" value="Enter Marks">
        </form>
    </div>
    <footer class="footer">  
<p>@Copyright © 2023 .Designed by Sivaperumal Web Developer</p>  
</footer>  

 <script>
  // Get the elements by their IDs
        const semesterSelect = document.getElementById('semester');
        const subjectSelect = document.getElementById('subject');

        // Add event listener to the semester select dropdown
        semesterSelect.addEventListener('change', function () {
            const selectedSemester = semesterSelect.value;

            // Clear existing options
            subjectSelect.innerHTML = '';

   
            // Create options based on the selected semester
            if (selectedSemester == '1') {
                 const subsOption = document.createElement('option');
                subsOption.value = '';
                subsOption.textContent = 'Select Subjects (பாடங்களைத் தேர்ந்தெடுக்கவும்)';

                const proffessOption = document.createElement('option');
                proffessOption.value = 'tamil';
                proffessOption.textContent = 'Tamil (தமிழ்)';

                const matricsOption = document.createElement('option');
                matricsOption.value = 'english';
                matricsOption.textContent = 'English (ஆங்கிலம்)';

                
                const physicsOption = document.createElement('option');
                physicsOption.value = 'maths';
                physicsOption.textContent = 'Maths (கணிதம்)';

                
                const chemistryOption = document.createElement('option');
                chemistryOption.value = 'Physics';
                chemistryOption.textContent = 'Physics (இயற்பியல்)';

                
                const pythonOption = document.createElement('option');
                pythonOption.value = 'chemistry';
                pythonOption.textContent = 'Chemistry (வேதியியல்)';

                
                const tamilOption = document.createElement('option');
                tamilOption.value = 'computer';
                tamilOption.textContent = 'computer (கணினி)';

                
                
                
                subjectSelect.appendChild(subsOption);
                subjectSelect.appendChild(proffessOption);
                subjectSelect.appendChild(matricsOption);
                subjectSelect.appendChild(physicsOption);
                subjectSelect.appendChild(chemistryOption);
                subjectSelect.appendChild(pythonOption);
                subjectSelect.appendChild(tamilOption);
              
            } else if (selectedSemester === '2') {
                const subsOption = document.createElement('option');
                subsOption.value = '';
                subsOption.textContent = 'Select Subjects (பாடங்களைத் தேர்ந்தெடுக்கவும்)';
                
                const proengOption = document.createElement('option');
                proengOption.value = 'HS3252';
                proengOption.textContent = 'Tamil (தமிழ்)';

                const statisOption = document.createElement('option');
                statisOption.value = 'MA3251';
                statisOption.textContent = 'English (ஆங்கிலம்)';

                
                const phyinsOption = document.createElement('option');
                phyinsOption.value = 'PH3256';
                phyinsOption.textContent = 'Maths (கணிதம்)';

                
                const eeeOption = document.createElement('option');
                eeeOption.value = 'BE3251';
                eeeOption.textContent = 'Physics (இயற்பியல்)';

                
                const egOption = document.createElement('option');
                egOption.value = 'GE3251';
                egOption.textContent ='Chemistry (வேதியியல்)';

                
                const cprogOption = document.createElement('option');
                cprogOption.value = 'CS3251';
                cprogOption.textContent =  'Biology (உயிரியல்)';

                
                
                subjectSelect.appendChild(subsOption);
                subjectSelect.appendChild(proengOption);
                subjectSelect.appendChild(statisOption);
                subjectSelect.appendChild(phyinsOption);
                subjectSelect.appendChild(eeeOption);
                subjectSelect.appendChild(egOption);
                subjectSelect.appendChild(cprogOption);
                
            }else if (selectedSemester === '3') {
                const subsOption = document.createElement('option');
                subsOption.value = '';
                subsOption.textContent = 'Select Subjects (பாடங்களைத் தேர்ந்தெடுக்கவும்)';
                
                const proengOption = document.createElement('option');
                proengOption.value = 'HS3252';
                proengOption.textContent = 'Tamil (தமிழ்)';

                const statisOption = document.createElement('option');
                statisOption.value = 'MA3251';
                statisOption.textContent = 'English (ஆங்கிலம்)';

                
                const phyinsOption = document.createElement('option');
                phyinsOption.value = 'PH3256';
                phyinsOption.textContent = 'Maths (கணிதம்)';

                
                const eeeOption = document.createElement('option');
                eeeOption.value = 'BE3251';
                eeeOption.textContent = 'Physics (இயற்பியல்)';

                
                const egOption = document.createElement('option');
                egOption.value = 'GE3251';
                egOption.textContent ='Chemistry (வேதியியல்)';

                
                const cprogOption = document.createElement('option');
                cprogOption.value = 'CS3251';
                cprogOption.textContent =  'Botany (தாவரவியல்)';

                const projectOption = document.createElement('option');
                projectOption.value = '';
                projectOption.textContent = 'Zology (விலங்கியல்)';


                
                
                subjectSelect.appendChild(subsOption);
                subjectSelect.appendChild(proengOption);
                subjectSelect.appendChild(statisOption);
                subjectSelect.appendChild(phyinsOption);
                subjectSelect.appendChild(eeeOption);
                subjectSelect.appendChild(egOption);
                subjectSelect.appendChild(cprogOption);
                subjectSelect.appendChild(projectOption);
                
            }else if (selectedSemester === '4') {
                const subsOption = document.createElement('option');
                subsOption.value = '';
                subsOption.textContent = 'Select Subjects (பாடங்களைத் தேர்ந்தெடுக்கவும்)';
                
                const proengOption = document.createElement('option');
                proengOption.value = 'HS3252';
                proengOption.textContent = 'Tamil (தமிழ்)';

                const statisOption = document.createElement('option');
                statisOption.value = 'MA3251';
                statisOption.textContent = 'English (ஆங்கிலம்)';

                
                const phyinsOption = document.createElement('option');
                phyinsOption.value = 'PH3256';
                phyinsOption.textContent = 'Maths (கணிதம்)';

                
                const eeeOption = document.createElement('option');
                eeeOption.value = 'BE3251';
                eeeOption.textContent = 'Physics (இயற்பியல்)';

                
                const egOption = document.createElement('option');
                egOption.value = 'GE3251';
                egOption.textContent ='Chemistry (வேதியியல்)';

                
                const cprogOption = document.createElement('option');
                cprogOption.value = 'CS3251';
                cprogOption.textContent =  'Botany (தாவரவியல்)';

                const projectOption = document.createElement('option');
                projectOption.value = '';
                projectOption.textContent = 'Zology (விலங்கியல்)';


                
                
                subjectSelect.appendChild(subsOption);
                subjectSelect.appendChild(proengOption);
                subjectSelect.appendChild(statisOption);
                subjectSelect.appendChild(phyinsOption);
                subjectSelect.appendChild(eeeOption);
                subjectSelect.appendChild(egOption);
                subjectSelect.appendChild(cprogOption);
                subjectSelect.appendChild(projectOption);
                
            }else if (selectedSemester === '5') {
                const subsOption = document.createElement('option');
                subsOption.value = '';
                subsOption.textContent = 'Select Subjects (பாடங்களைத் தேர்ந்தெடுக்கவும்)';
                
                const proengOption = document.createElement('option');
                proengOption.value = 'HS3252';
                proengOption.textContent = 'Tamil (தமிழ்)';

                const statisOption = document.createElement('option');
                statisOption.value = 'MA3251';
                statisOption.textContent = 'English (ஆங்கிலம்)';

                
                const phyinsOption = document.createElement('option');
                phyinsOption.value = 'PH3256';
                phyinsOption.textContent = 'Maths (கணிதம்)';

                
                const eeeOption = document.createElement('option');
                eeeOption.value = 'BE3251';
                eeeOption.textContent = 'Physics (இயற்பியல்)';

                
                const egOption = document.createElement('option');
                egOption.value = 'GE3251';
                egOption.textContent ='Chemistry (வேதியியல்)';

                
                const cprogOption = document.createElement('option');
                cprogOption.value = 'CS3251';
                cprogOption.textContent =  'computer (கணினி)';

                

                
                
                subjectSelect.appendChild(subsOption);
                subjectSelect.appendChild(proengOption);
                subjectSelect.appendChild(statisOption);
                subjectSelect.appendChild(phyinsOption);
                subjectSelect.appendChild(eeeOption);
                subjectSelect.appendChild(egOption);
                subjectSelect.appendChild(cprogOption);
             
                
            }else if (selectedSemester === '6') {
                const subsOption = document.createElement('option');
                subsOption.value = '';
                subsOption.textContent = 'Select Subjects (பாடங்களைத் தேர்ந்தெடுக்கவும்)';
                
                const proengOption = document.createElement('option');
                proengOption.value = 'HS3252';
                proengOption.textContent = 'Tamil (தமிழ்)';

                const statisOption = document.createElement('option');
                statisOption.value = 'MA3251';
                statisOption.textContent = 'English (ஆங்கிலம்)';

                
                const phyinsOption = document.createElement('option');
                phyinsOption.value = 'PH3256';
                phyinsOption.textContent = 'Maths (கணிதம்)';

                
                const eeeOption = document.createElement('option');
                eeeOption.value = 'BE3251';
                eeeOption.textContent = 'Physics (இயற்பியல்)';

                
                const egOption = document.createElement('option');
                egOption.value = 'GE3251';
                egOption.textContent ='Chemistry (வேதியியல்)';

                
                const cprogOption = document.createElement('option');
                cprogOption.value = 'CS3251';
                cprogOption.textContent =  'Biology (உயிரியல்)';



                
                
                subjectSelect.appendChild(subsOption);
                subjectSelect.appendChild(proengOption);
                subjectSelect.appendChild(statisOption);
                subjectSelect.appendChild(phyinsOption);
                subjectSelect.appendChild(eeeOption);
                subjectSelect.appendChild(egOption);
                subjectSelect.appendChild(cprogOption);
               
                
            }else if (selectedSemester === '7') {
                const subsOption = document.createElement('option');
                subsOption.value = '';
                subsOption.textContent = 'Select Subjects (பாடங்களைத் தேர்ந்தெடுக்கவும்)';
                
                const proengOption = document.createElement('option');
                proengOption.value = 'HS3252';
                proengOption.textContent = 'Tamil (தமிழ்)';

                const statisOption = document.createElement('option');
                statisOption.value = 'MA3251';
                statisOption.textContent = 'English (ஆங்கிலம்)';

                
                const phyinsOption = document.createElement('option');
                phyinsOption.value = 'PH3256';
                phyinsOption.textContent = 'Maths (கணிதம்)';

                
                const eeeOption = document.createElement('option');
                eeeOption.value = 'BE3251';
                eeeOption.textContent = 'Physics (இயற்பியல்)';

                
                const egOption = document.createElement('option');
                egOption.value = 'GE3251';
                egOption.textContent ='Chemistry (வேதியியல்)';

                
                const cprogOption = document.createElement('option');
                cprogOption.value = 'CS3251';
                cprogOption.textContent =  'Botany (தாவரவியல்)';

                const projectOption = document.createElement('option');
                projectOption.value = '';
                projectOption.textContent = 'Zology (விலங்கியல்)';


                
                
                subjectSelect.appendChild(subsOption);
                subjectSelect.appendChild(proengOption);
                subjectSelect.appendChild(statisOption);
                subjectSelect.appendChild(phyinsOption);
                subjectSelect.appendChild(eeeOption);
                subjectSelect.appendChild(egOption);
                subjectSelect.appendChild(cprogOption);
                subjectSelect.appendChild(projectOption);
                
            }else if (selectedSemester === '8') {
                const subsOption = document.createElement('option');
                subsOption.value = '';
                subsOption.textContent = 'Select Subjects (பாடங்களைத் தேர்ந்தெடுக்கவும்)';
                
                const proengOption = document.createElement('option');
                proengOption.value = 'HS3252';
                proengOption.textContent = 'Tamil (தமிழ்)';

                const statisOption = document.createElement('option');
                statisOption.value = 'MA3251';
                statisOption.textContent = 'English (ஆங்கிலம்)';

                
                const phyinsOption = document.createElement('option');
                phyinsOption.value = 'PH3256';
                phyinsOption.textContent = 'Maths (கணிதம்)';

                
                const eeeOption = document.createElement('option');
                eeeOption.value = 'BE3251';
                eeeOption.textContent = 'Physics (இயற்பியல்)';

                
                const egOption = document.createElement('option');
                egOption.value = 'GE3251';
                egOption.textContent ='Chemistry (வேதியியல்)';

                
                const cprogOption = document.createElement('option');
                cprogOption.value = 'CS3251';
                cprogOption.textContent =  'Botany (தாவரவியல்)';

                const projectOption = document.createElement('option');
                projectOption.value = '';
                projectOption.textContent = 'Zology (விலங்கியல்)';


                
                
                subjectSelect.appendChild(subsOption);
                subjectSelect.appendChild(proengOption);
                subjectSelect.appendChild(statisOption);
                subjectSelect.appendChild(phyinsOption);
                subjectSelect.appendChild(eeeOption);
                subjectSelect.appendChild(egOption);
                subjectSelect.appendChild(cprogOption);
                subjectSelect.appendChild(projectOption);
                
            }
        });
    </script>

</body>
</html>
